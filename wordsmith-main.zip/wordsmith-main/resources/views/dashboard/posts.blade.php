@extends('dashboard.layout')

@section('content')

    <div class="w-full ml-64 bg-gray-100">

        <!-- Main Content -->
        <div class="relative px-8 py-5">
            <div class="max-w-4xl">
                <div class="flex items-start justify-between">
                    <h1 class="font-bold text-gray-800">Posts</h1>
                    <a href="/dashboard/posts/create" class="px-4 py-2 text-xs font-bold text-white uppercase bg-green-500 rounded shadow">New Post</a>
                </div>

                <div class="flex flex-col min-w-full mt-6 overflow-hidden leading-normal rounded-lg shadow">
                    <div class="flex bg-white cursor-pointer hover:bg-yellow-50">
                        <div class="w-3/6 px-5 py-3 text-xs font-semibold tracking-wider text-left text-gray-700 uppercase bg-gray-100 border-b-2 border-gray-200">Post Title</div>
                        <div class="w-1/6 px-5 py-3 text-xs font-semibold tracking-wider text-left text-gray-700 uppercase bg-gray-100 border-b-2 border-gray-200">Created</div>
                        <div class="w-1/6 px-5 py-3 text-xs font-semibold tracking-wider text-left text-gray-700 uppercase bg-gray-100 border-b-2 border-gray-200">Updated</div>
                        <div class="w-1/6 px-5 py-3 text-xs font-semibold tracking-wider text-left text-gray-700 uppercase bg-gray-100 border-b-2 border-gray-200">Status</div>
                    </div>

                    @foreach(App\Models\Post::orderBy('created_at', 'DESC')->get() as $post)
                        <div class="flex justify-between bg-white cursor-pointer hover:bg-yellow-50" onclick="window.location = '/dashboard/posts/edit/{{ $post->id }}'">
                            <div class="w-3/6 px-5 py-5 text-sm">
                                <div class="flex flex-col">
                                    <p class="text-gray-900 whitespace-no-wrap">{{ $post->title }}</p>
                                    <code class="block mt-1 text-xs text-gray-600 whitespace-no-wrap">/{{ $post->slug }}</code>
                                </div>
                            </div>
                            <div class="w-1/6 px-5 py-5 text-sm">
                                <p class="text-gray-900 whitespace-no-wrap">{{ $post->created_at }}</p>
                            </div>
                            <div class="w-1/6 px-5 py-5 text-sm">
                                <p class="text-gray-900 whitespace-no-wrap">{{ $post->updated_at }}</p>
                            </div>
                            <div class="w-1/6 px-5 py-5 text-sm">
                                @if($post->status == App\Models\Post::STATUS_PUBLISHED)
                                    <span class="relative inline-block px-3 py-1 font-semibold leading-tight text-green-900">
                                        <span aria-hidden="" class="absolute inset-0 bg-green-200 rounded-full opacity-50"></span>
                                        <span class="relative">Published</span>
                                    </span>
                                @else
                                    <span class="relative inline-block px-3 py-1 font-semibold leading-tight text-gray-900">
                                        <span aria-hidden="" class="absolute inset-0 bg-gray-200 rounded-full opacity-50"></span>
                                        <span class="relative">Draft</span>
                                    </span>
                                @endif
                            </div>
                        </div>
                    @endforeach

                </div>
            </div>
        </div>
        <!-- End Main Content -->

    </div>

@endsection
