<!-- Sidebar -->
<div class="fixed left-0 flex flex-col items-start justify-between w-64 h-full max-h-screen p-5 bg-white">

    <!-- Logo -->
    <svg class="w-auto h-4 fill-current" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 202 120"><defs/><g fill-rule="evenodd"><path d="M0 0l69.245 120L96 73.633 53.51 0zM64 0l69.244 120L160 73.633 117.51 0zM127 0l37.5 65L202 0z"/></g></svg>

    <nav class="-mt-10 text-sm text-gray-800">
        <a href="/dashboard" class="@if(Request::is('dashboard')){{ 'font-bold' }}@else{{ 'font-medium hover:text-black' }}@endif block py-1">Dashboard</a>
        <a href="/dashboard/posts" class="@if(Request::is('dashboard/posts')){{ 'font-bold' }}@else{{ 'font-medium hover:text-black' }}@endif block py-1">Posts</a>
        <a href="/dashboard/settings" class="@if(Request::is('dashboard/settings')){{ 'font-bold' }}@else{{ 'font-medium hover:text-black' }}@endif block py-1">Settings</a>
    </nav>

    <div class="text-gray-500">
        <a href="{{ url('/') }}" class="flex items-center text-xs font-bold text-blue-500 no-underline hover:text-black">
            <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            Back to My Blog
        </a>
    </div>
</div>
<!-- End Sidebar -->
