@extends('layouts.app')

@section('section')
@endsection
