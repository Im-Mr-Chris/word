<div class="w-full ml-64 bg-gray-100">
    <!-- Main Content -->
    <div class="relative px-8 py-5">
        <div class="max-w-4xl">
            <div class="flex items-start justify-between">
                <h1 class="font-bold text-gray-800">Settings</h1>
                <div wire:click="newSetting" class="px-4 py-2 text-xs font-bold text-white uppercase bg-green-500 rounded shadow cursor-pointer">New Setting</div>
            </div>

            @foreach($settings as $index => $setting)
                <div class="flex items-center mt-3 space-x-3">
                    <input type="text" wire:model.lazy="settings.{{ $index }}.key" class="block w-full px-4 py-2 leading-normal bg-white border border-gray-300 rounded-lg appearance-none focus:outline-none focus:shadow-outline">
                    <input type="text" wire:model.lazy="settings.{{ $index }}.value" class="block w-full px-4 py-2 leading-normal bg-white border border-gray-300 rounded-lg appearance-none focus:outline-none focus:shadow-outline">
                    <div wire:click="delete('{{ $index }}')" class="flex items-center justify-center flex-shrink-0 w-10 h-10 text-red-600 bg-red-100 rounded-md cursor-pointer">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>
