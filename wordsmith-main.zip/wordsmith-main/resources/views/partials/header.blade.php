<section class="w-full">
    <a href="{{ setting('top-bar-link') }}" class="block w-full h-10 bg-gray-900">
        <span class="flex justify-center block h-full px-10 mx-auto lg:max-w-7xl">
            <span class="relative inline-flex items-center justify-center w-auto h-full space-x-4 sm:max-w-xl md:max-w-full">
                <span class="text-sm font-medium text-white">Latest Update: New Course Released 🎉</span>
                <span class="absolute right-0 hidden text-xs font-medium text-gray-200 underline uppercase transform translate-x-full sm:block">
                    <span class="ml-2">learn more</span>
                </span>
            </span>
        </span>
    </a>
</section>

<!-- Header Nav -->
<section class="w-full text-gray-700 bg-white border-b border-gray-100">
    <div class="px-10 py-6 mx-auto max-w-7xl md:flex-row">
        <div class="flex flex-col flex-wrap items-center md:flex-row">

            <nav class="flex flex-wrap items-center order-2 my-5 space-x-4 text-xs font-semibold tracking-wide uppercase md:w-2/5 md:ml-auto md:my-0 md:order-1 sm:space-x-6">
                <a href="/" class="text-gray-500 hover:text-gray-500">Home</a>
                <a href="/about" class="text-gray-400 hover:text-gray-500">About</a>
                <a href="/projects" class="text-gray-400 hover:text-gray-500">Projects</a>
            </nav>
            <a href="/" class="flex items-center order-1 font-medium text-gray-700 text-gray-900 md:order-2 md:w-1/5 md:items-center md:justify-center">
                <svg class="w-auto h-4 mr-2 fill-current" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 202 120"><defs></defs><g fill-rule="evenodd"><path d="M0 0l69.245 120L96 73.633 53.51 0zM64 0l69.244 120L160 73.633 117.51 0zM127 0l37.5 65L202 0z"></path></g></svg>
                <span class="text-xs font-bold uppercase">Wordsmith</span>
            </a>
            <div class="inline-flex items-center order-3 space-x-6 md:w-2/5 md:order-3 md:justify-end">
                <a href="/contact" class="inline-flex tracking-wide uppercase text-xs items-center justify-center px-5 py-2.5 font-semibold text-gray-100 hover:text-white bg-gray-800 border border-transparent rounded-md shadow-sm hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">Contact</a>
            </div>
        </div>
    </div>
</section>
