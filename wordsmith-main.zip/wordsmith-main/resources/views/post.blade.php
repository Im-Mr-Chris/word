@extends('layouts.app')

@section('content')

    @if($post->type == App\Models\Post::TYPE_POST)
        <div class="absolute top-0 left-0 hidden w-full h-auto mt-32 bg-center bg-cover lg:block lg:h-96" style="background-image:url('{{ $post->image }}')">
            <div class="absolute w-full h-full bg-gradient-to-b from-transparent to-white"></div>
            <div class="absolute w-full h-full bg-white opacity-80"></div>
        </div>

        <div class="box-content relative max-w-6xl mx-auto overflow-hidden lg:pt-12 lg:px-10 lg:rounded-md h-96">
            <img src="{{ $post->image }}" class="object-cover w-full h-96 lg:rounded-md" />
        </div>
    @endif

    <article class="px-6 py-20 mx-auto prose xl:prose-xl 2xl:prose-2xl lg:px-0">
        <h1>{{ $post->title }}</h1>
        {!! Str::markdown($post->body) !!}
    </article>
@endsection
